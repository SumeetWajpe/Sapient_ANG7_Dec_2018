import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { ProductService } from './products.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts/posts.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,ShoppingCartComponent,
    ProductComponent, QuantityPipe, 
    PostsComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers:[ProductService,PostsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
