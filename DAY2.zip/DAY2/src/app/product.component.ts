import { Component, Input } from "@angular/core";

import {Product} from './product.model';

@Component({
    selector:`product`,
    templateUrl:'./product.template.html',   
    styleUrls:[`./product.style.css`]
})
export class ProductComponent{
    isHighlighted:boolean=false;  
    isFree:boolean=false;
    @Input()     prodDetails:Product=new Product();
     
}