import { Component } from "@angular/core";
import {Product} from './product.model';
import { ProductService } from './products.service';

@Component({
    selector:`cart`,
    templateUrl:`./shoppingcart.template.html`,
    styleUrls:['./shoppingcart.style.css']
    
    })
export class ShoppingCartComponent{
   heading:string="Shopping Cart";
   txtCompany:string="";
   productToBeSearched:string="";
   products:Product[] =[];
   newProduct:Product = new Product();

   // DI
   constructor(public theservInstance:ProductService){
        this.products =      this.theservInstance.getAllProducts();
   }
   
             HandleClick(){
                 this.heading = "Flipkart !"; // change the model !
             }
             AddNewProduct(theForm){
                 // Add a new product !

                 if(theForm.valid){
                    this.products.push(this.newProduct);
                    this.newProduct = new Product(); // resetting the model !
                    theForm.reset();
                 }

               
             }
           
}