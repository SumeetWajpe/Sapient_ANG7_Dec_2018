import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
  template:`  
    <div *ngFor="let c of listofcourses">
          <course [coursedetails]="c" ></course>
    </div>  `,
  // templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  listofcourses:Course[]= [
    new Course("React","3 Days",3000,"https://images.g2crowd.com/uploads/product/hd_favicon/1509756066/react-native.svg"),
    new Course("Node","3 Days",4000,"https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/256/full/nodejslogo.png"),
    new Course("Angular","5 Days",3000,"https://angular.io/assets/images/logos/angular/angular.svg"),
    new Course("Python","5 Days",5000,"https://www.python.org/static/opengraph-icon-200x200.png")
  ];


  

}
