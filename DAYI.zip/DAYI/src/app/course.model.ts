export class Course{
    constructor(
        public name?:string,
        public duration?:string,
        public price?:number,
        public imageUrl?:string        
        ){

    }
}