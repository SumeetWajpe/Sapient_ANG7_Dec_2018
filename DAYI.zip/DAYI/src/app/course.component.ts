import {Component, Input} from '@angular/core';
import { Course } from './course.model';

@Component({
    selector:`course`,
    templateUrl:   `./course.template.html` 
})
export default class CourseComponent{
    @Input()   coursedetails:Course={name:"Angular",price:50000};
}

export const PI = 3.14;

export function Add(){
    
}